<?php

include ('template/index.phtml');

$dictionnaire =
[
  "hello" => "bonjour",
  "car" => "véhicule",
  "screen" => "écran"
];

if(!empty($_POST['word'])){
  $mot = $_POST['word'];
  $destination = $_POST['direction'];


  // if($destination == 'toFrench'){
  //   if(array_key_exists($mot, $dictionnaire)){
  //     echo "le mot $mot se traduit par : " . $dictionnaire[$mot]. " en Français";
  //   }else{
  //     echo "le mot $mot n'est pas dans mon dictionnaire anglais";
  //   }
  // }else{
  //   if(in_array($mot, $dictionnaire)){
  //     $translate = array_search($mot, $dictionnaire);
  //     echo "le mot $mot se traduit par : " . $translate . " en Anglais";
  //   }else{
  //     echo "le mot $mot n'est pas dans mon dictionnaire français";
  //   }
  // }

  switch ($destination) {
    case 'toFrench':
      if(array_key_exists($mot, $dictionnaire)){
        echo "le mot $mot se traduit par : " . $dictionnaire[$mot]. " en Français";
      }else{
        echo "le mot $mot n'est pas dans mon dictionnaire anglais";
      }
      break;

    case 'toEnglish':
      if(in_array($mot, $dictionnaire)){
        $translate = array_search($mot, $dictionnaire);
        echo "le mot $mot se traduit par : " . $translate . " en Anglais";
      }else{
        echo "le mot $mot n'est pas dans mon dictionnaire français";
      }
      break;
  }

}



